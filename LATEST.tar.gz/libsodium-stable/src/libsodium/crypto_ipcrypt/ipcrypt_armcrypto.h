#ifndef ipcrypt_armcrypto_H
#define ipcrypt_armcrypto_H

#include "implementations.h"

extern struct ipcrypt_implementation ipcrypt_armcrypto_implementation;

#endif
