#ifndef asm_cet_H
#define asm_cet_H 1

#if HAVE_CET_H
# include <cet.h>
#endif
#ifndef _CET_ENDBR
# define _CET_ENDBR
#endif

#endif
